# Adaptation to the Navoneel "Brain MRI Images for Brain Tumor Detection" dataset (no / yes)

Dataset: https://www.kaggle.com/datasets/navoneel/brain-mri-images-for-brain-tumor-detection
Two folders, `no` (no tumour) and `yes` (tumour); a few hundred images of mixed formats (.jpg/.JPG/.jpeg/.png),
sizes and colour modes. The Kaggle archive usually holds every image twice (`no/`, `yes/` and
`brain_tumor_dataset/no/`, `brain_tumor_dataset/yes/`). There is **no train/test split** and no patient ID.
The exact numbers after cleaning are written by the preparation script to `data/brain_mri_yesno/prepare_report.json`;
nothing in this repository hard-codes them.

## What changed relative to the 4-class (Nickparvar) version

| Area | Change | Why |
|---|---|---|
| Data preparation | new `scripts/prepare_yesno_dataset.py`; `scripts/download_dataset.py` now fetches the Navoneel set and calls it | the raw archive has no split and contains duplicates |
| De-duplication | byte-identical files removed (this removes the duplicate `brain_tumor_dataset/` copy); a file present in both `no` and `yes` is dropped as a label conflict | duplicates across the split leak the test set |
| Near-duplicates | 256-bit difference hash; images within 6 bits are grouped (groups capped at 8) and a group always lands in one split | the same slice saved twice in another size/format would otherwise leak |
| Split | stratified, group-aware hold-out, 20 % test, `--seed 0`; optional `--folds K` writes K group-stratified folds | with ~50 test images one split is noisy; folds give a better estimate |
| Dataset spec | built-in `brain_mri_yesno` (default of `main.py`): classes `no`, `yes`; prompts "An MRI scan showing a healthy brain with no tumor." / "... a brain tumor."; positive class `yes` | |
| Metrics | every evaluation also reports balanced accuracy, sensitivity (recall of `yes`), specificity (recall of `no`), PPV, NPV and ROC-AUC of p(yes); `predictions.csv` stores per-class probabilities | accuracy alone hides the clinically relevant error types and the class imbalance |
| Top-K anchors | K = 2 by default (both class prompts are anchors; the attention of Eq. 13 weights them); K = 1 is the only other value (anchor = frozen-CLIP top-1 class) | K <= C = 2 |
| Base-to-new (Table I) | **skipped** for this dataset | with 2 classes the "base" half is one class: training would see a single label and the cross-entropy is constant |
| Ablation (Table V), sweeps (Fig. 3/4), stability (Table VI), t-SNE (Fig. 5) | run on the **16-shot** protocol instead of base-to-new; the report shows Acc / Bal. acc / Sens / Spec / AUC | the paper's base-to-new setting is undefined here; 16 shots is the paper's default shot count |
| K sweep | {1, 2} | K <= C |
| Cross-dataset (Table III) | targets `br35h` (no/yes), `brain_tumor_mri_binary` (Nickparvar read as no/yes: notumor -> no, glioma/meningioma/pituitary -> yes), `brain_tumor_mri` (4 classes), `figshare_brain` (3 tumour types); missing ones are skipped | a target with the same no/yes labels is a pure domain shift and is evaluated in "base" mode (like Table IV); targets with other classes stay "novel" (unseen classes) |
| Domain generalisation (Table IV) | unchanged: synthetic noise / bias field / low resolution / sketch copies of the test split | |
| Legacy single-run tooling | `CLASS_NAMES = ("no", "yes")`; configs point to `data/brain_mri_yesno`; configs that needed C >= 3 (K=3/4, base2new) removed, K=1 configs added | |

The MQAdapter itself (Eqs. 5-16: 8-qubit shared VQC, cross-modal attention over anchors, residual injection
into blocks 6-11 with gamma) is unchanged.

## How to read results on this dataset

* **The coarse stage does not filter anything at K = 2.** Every class is an anchor, so `coarse_topk_recall` is
  100 % by construction. Any MQAdapter gain comes from the fine stage (the cross-modal quantum interaction and the
  residual into the class token), not from candidate filtering - which is the paper's motivation for large C.
  The K = 1 point of the sweep shows what happens when the anchor is only CLIP's own guess.
* **Small test set.** With a 20 % split the test set has roughly 50 images; one image is about 2 accuracy points.
  Differences of 1-2 points between methods are within noise. Use 3 seeds and, for anything you want to claim,
  the 5-fold split (`--folds 5`, then one `main.py` run per fold with `--data-root data/brain_mri_yesno_fold{k}
  --out runs/fold{k}`) and report mean +/- std over folds.
* **Few-shot at 16 shots** uses only 32 training images; the "all" task uses every training image (~200).
  The `all` task is the practical number for this dataset.
* **Imbalance.** `yes` outnumbers `no`. Few-shot sampling is balanced; the `all` task is not. Look at balanced
  accuracy, sensitivity and specificity, not only accuracy.
* **No patient IDs** exist, so the split is image-level, not patient-level. Several slices of one patient can
  still fall on both sides (near-duplicate grouping only catches visually near-identical images). Do not claim
  patient-level generalisation.
* The images vary a lot (scanner, sequence, crops, annotations burnt into some images). CLIP zero-shot on
  this task is weak; that is expected for a natural-image model.
