# Running the end-to-end pipeline (`main.py`)

## 0. Install (12 GB GPU, 64 GB RAM machine)

```text
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt
python -m pytest -q tests          # do this first; report any failure with its traceback
```

## 1. Plumbing check on synthetic data (no downloads, CPU is fine)

```text
python main.py --make-dummy-data data/dummy --backend fake --quick --seeds 1 --shots 1 2
```
This runs every paper task for the default methods with a fake CLIP and writes `runs/main/REPORT.md`.
The numbers are meaningless; the point is that nothing crashes. Add `--out runs/smoke` to keep it apart.

## 2. Data

```text
python scripts/download_dataset.py                 # Navoneel no/yes set -> data/brain_mri_yesno/{Training,Testing}/{no,yes}
python scripts/download_dataset.py --zip archive.zip   # same, from a manually downloaded zip
python scripts/download_dataset.py --folds 5 --overwrite   # also data/brain_mri_yesno_fold{0..4}
```
Cross-dataset targets (optional; skipped with a message if absent):
* `data/br35h/Testing/{no,yes}/*.jpg` (Br35H) - same labels
* `data/brain_tumor_mri/Testing/{glioma,meningioma,notumor,pituitary}` (`python scripts/download_dataset.py --dataset nickparvar`),
  used twice: as `brain_tumor_mri_binary` (no/yes) and as `brain_tumor_mri` (4 classes)
* `data/figshare_brain/Testing/{glioma,meningioma,pituitary}/*.jpg` (Cheng et al. 2017, exported to JPG)

Other locations: `--target-root br35h=/path/to/it figshare_brain=/path/to/that`.

## 3. Real runs

```text
python main.py --dry-run                                    # list every run that would be executed
python main.py --tasks topk                                 # Fig. 1 only (minutes)
python main.py --tasks fewshot report --seeds 1             # Table II, one seed
python main.py                                              # whole paper suite, 3 seeds
python main.py --tasks all report --methods baselines hosts qvlm   # every training image (not in the paper)
# 5-fold estimate (after --folds 5):
for k in 0 1 2 3 4; do python main.py --data-root data/brain_mri_yesno_fold$k --out runs/fold$k --tasks topk all fewshot report; done
```

Useful flags

| flag | meaning |
|---|---|
| `--methods maple maple+mqa` | any method, `+mqa` adds MQAdapter; groups `baselines`, `hosts`, `qvlm`, `paper`, `everything` |
| `--k 1` | Top-K anchors (default 2 = both classes on the no/yes data; paper 5) |
| `--set gamma=0.002 mmrl_lambda=1.0` | override any hyper-parameter for all runs |
| `--mixed-precision` | AMP for the CLIP towers (the VQC stays fp32) |
| `--selection best_val` | pick the epoch with the lowest validation loss instead of the last epoch |
| `--epochs-scale 0.5` | shorten every schedule |
| `--continue-on-error` | keep going if one run fails (failures in `runs/main/failures.json`) |
| `--force` | re-run runs that already have `result.json` (otherwise they are skipped, so you can resume) |

## 4. Outputs

```
runs/main/
  REPORT.md                 Tables I-VII, Fig. 1/3/4 numbers, full-data table
  all_results.csv           one row per (run, evaluation set)
  fig3_fig4_sweeps.png, fig5_tsne.png, topk/fig1_topk.png
  efficiency.json
  <task>/<method>[__variant]/shots<S>/seed<N>/
      result.json  config.json  split.json  train_summary.json  weights.pt (non-CLIP weights only)
      eval/<set>/metrics.json  predictions.csv  confusion_matrix.png  [features.npz]
```

## 5. Cost

Rough planning numbers, **not measured**: cross/DG runs train on 32 images (16 shots x 2 classes) and take
minutes; few-shot runs with 100-200 epochs take a few minutes each on a GPU; the "all" task trains on ~200
images. The dataset is small, so the whole suite is far cheaper than on the 4-class set. `--dry-run` prints the run count; the default paper
suite is roughly 200 runs. Start with `--seeds 1`.

## 6. Interpreting results on the no/yes data

See `docs/YESNO_ADAPTATION.md`. In short: K = 2 means the coarse stage filters nothing; base-to-new is skipped;
Tables V/VI and Fig. 3/4/5 use 16-shot runs; the test set is ~50 images, so use seeds and the 5-fold split and
read sensitivity / specificity / AUC, not just accuracy. The split is not patient-independent.
