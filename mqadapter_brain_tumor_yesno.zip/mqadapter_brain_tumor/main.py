#!/usr/bin/env python
"""End-to-end reproduction driver: zero-shot VLM -> fine-tuned VLMs -> quantum (MQAdapter) fine-tuned VLMs,
over every protocol of the MQAdapter paper, then one report with the paper's tables.

Primary dataset: Kaggle "Brain MRI Images for Brain Tumor Detection" (Navoneel), classes no / yes, prepared
by scripts/download_dataset.py (or scripts/prepare_yesno_dataset.py) into data/brain_mri_yesno.

Quick plumbing check (no downloads, synthetic images, fake CLIP, ~1-3 min on CPU):
    python main.py --make-dummy-data data/dummy --backend fake --quick

Everything on the yes/no MRI data (real CLIP ViT-B/16; GPU hours - see docs/RUNNING.md):
    python main.py

Binary datasets (2 classes): base-to-new (Table I) is undefined - it would train on a single class - so it is
skipped, and the analyses the paper runs on base-to-new (Table V ablation, Fig. 3/4 sweeps, Table VI stability,
Fig. 5 t-SNE) run on the 16-shot protocol instead. K (Top-K anchors) is at most 2 = the number of classes.

Pick tasks / methods / seeds:
    python main.py --tasks fewshot report --methods maple maple+mqa mmrlpp mmrlpp+mqa --seeds 1
    python main.py --tasks all --methods zeroshot coop maple+mqa --seeds 1 2 3       # all training images
    python main.py --dry-run                                                          # list the runs only

Methods  : zeroshot, linear_probe, clip_adapter, coop, cocoop, maple, promptsrc, mmrl, mmrlpp; any of them
           with "+mqa" adds the MQAdapter plug-in ("zeroshot+mqa" = stand-alone MQAdapter on frozen CLIP).
           Groups: baselines, hosts, qvlm, paper (default), everything.
Tasks    : topk (Fig.1)  all (full data, not in paper)  base2new (Tab.I)  fewshot (Tab.II)  cross (Tab.III)
           dg (Tab.IV)  ablation (Tab.V)  sweeps (Fig.3/4)  stability (Tab.VI)  efficiency (Tab.VII)
           tsne (Fig.5)  report
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

GROUPS = {
    "baselines": ["zeroshot", "linear_probe", "clip_adapter", "coop", "cocoop"],
    "hosts": ["maple", "promptsrc", "mmrlpp"],
    "qvlm": ["zeroshot+mqa", "maple+mqa", "promptsrc+mqa", "mmrlpp+mqa"],
}
GROUPS["paper"] = ["zeroshot"] + GROUPS["hosts"] + GROUPS["qvlm"][1:]
GROUPS["everything"] = GROUPS["baselines"] + ["mmrl", "mmrl+mqa", "coop+mqa"] + GROUPS["hosts"] + GROUPS["qvlm"]
PAPER_TASKS = ["topk", "base2new", "fewshot", "cross", "dg", "ablation", "sweeps", "stability", "efficiency", "tsne", "report"]
ALL_TASKS = ["topk", "all"] + PAPER_TASKS[1:]
ABLATION_VARIANTS = {  # Table V (+ extra controls that isolate the circuit)
    "cross_attention": {"interaction": "cross_attention"},
    "separate_vqc": {"vqc_sharing": "separate"},
    "mlp": {"quantum_map": "mlp"},
    "identity": {"quantum_map": "identity"},
    "frozen_vqc": {"quantum_map": "frozen_vqc"},
}
SWEEP_K = [1, 2, 3, 4, 5, 6, 8, 10]
SWEEP_GAMMA = [0.0001, 0.0005, 0.001, 0.005, 0.01, 0.1]
SWEEP_START = [3, 4, 5, 6, 7, 8, 9, 10, 11]  # first adapted block, 0-indexed (default 6 -> blocks 6..11)


def parse_set(items):
    out = {}
    for it in items or []:
        k, _, v = it.partition("=")
        try:
            out[k] = json.loads(v)
        except json.JSONDecodeError:
            out[k] = v
    return out


def expand_methods(names):
    out = []
    for n in names:
        for m in GROUPS.get(n, [n]):
            if m not in out:
                out.append(m)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tasks", nargs="+", default=["paper"], help="task names, 'paper' (default) or 'everything'")
    ap.add_argument("--methods", nargs="+", default=["paper"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[1, 2, 3])
    ap.add_argument("--shots", nargs="+", type=int, default=[1, 2, 4, 8, 16])
    ap.add_argument("--dataset", default="brain_mri_yesno", help="built-in spec name or a .json spec")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--cross-targets", nargs="*", default=["br35h", "brain_tumor_mri_binary", "brain_tumor_mri", "figshare_brain"],
                    help="target datasets for Table III; missing ones are skipped")
    ap.add_argument("--target-root", nargs="*", default=[], metavar="NAME=PATH", help="root for a cross-dataset target")
    ap.add_argument("--dg-targets", nargs="*", default=[], help="real target-domain specs with the same classes")
    ap.add_argument("--dg-shifts", nargs="*", default=["noise", "bias", "lowres", "sketch"])
    ap.add_argument("--k", type=int, default=None, help="Top-K anchors (paper 5; default 2 when the dataset has <=5 classes, "
                    "which for the yes/no data means both class prompts are anchors)")
    ap.add_argument("--backend", default="open_clip", choices=["open_clip", "clip", "fake"])
    ap.add_argument("--no-download", action="store_true", help="fail instead of downloading CLIP weights")
    ap.add_argument("--device", default="auto")
    ap.add_argument("--out", default="runs/main")
    ap.add_argument("--augment", default=None, choices=[None, "mri", "clip"], help="default: mri for MRI specs, clip otherwise")
    ap.add_argument("--num-workers", type=int, default=4)
    ap.add_argument("--full-epochs", type=int, default=5, help="epochs for the full-data 'all' task")
    ap.add_argument("--epochs-scale", type=float, default=None, help="multiply every method's epochs")
    ap.add_argument("--mixed-precision", action="store_true")
    ap.add_argument("--selection", default="last", choices=["last", "best_val"])
    ap.add_argument("--set", nargs="*", default=[], metavar="KEY=VALUE", help="override any hyper-parameter for every run")
    ap.add_argument("--quick", action="store_true", help="1 epoch, 3 steps, 32 eval images: plumbing check only")
    ap.add_argument("--force", action="store_true", help="re-run experiments that already have result.json")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--make-dummy-data", default=None, metavar="DIR", help="create synthetic datasets in DIR and use them")
    ap.add_argument("--continue-on-error", action="store_true")
    args = ap.parse_args()

    tasks = ALL_TASKS if "everything" in args.tasks else (PAPER_TASKS if "paper" in args.tasks else args.tasks)
    methods = expand_methods(args.methods)
    target_roots = dict(t.split("=", 1) for t in args.target_root)
    data_root = args.data_root
    if args.make_dummy_data:
        from scripts.make_dummy_dataset import make_all

        roots = make_all(Path(args.make_dummy_data))
        primary = args.dataset if args.dataset in roots else "brain_mri_yesno"
        data_root = data_root or str(roots[primary])
        roots = {**roots, "brain_tumor_mri_binary": roots["brain_tumor_mri"]}
        target_roots = {**{k: str(v) for k, v in roots.items() if k != primary}, **target_roots}

    from mqa.datasets import load_spec, resolve_classes

    spec = load_spec(args.dataset, data_root)
    is_mri = spec.name in ("brain_mri_yesno", "brain_tumor_mri", "brain_tumor_mri_binary", "figshare_brain", "br35h") or "mri" in spec.template.lower()
    overrides = parse_set(args.set)
    try:
        n_cls = len(resolve_classes(spec))
    except SystemExit:
        n_cls = None
    if args.k is not None:
        overrides["k"] = args.k
    elif n_cls is not None and n_cls <= 5:
        overrides.setdefault("k", 2)
    proto = protocol_for(n_cls)
    if proto[0] != "base2new":
        if "base2new" in tasks:
            print(f"note: {spec.name} has {n_cls} classes -> base-to-new (Table I) is undefined and skipped; "
                  "ablation / sweeps / stability / t-SNE use the 16-shot protocol instead.")
        tasks = [t for t in tasks if t != "base2new"]
    cfg = dict(
        dataset=args.dataset, data_root=data_root, backend=args.backend, download_clip=not args.no_download, device=args.device,
        out_root=args.out, augment=args.augment or ("mri" if is_mri else "clip"), num_workers=args.num_workers,
        full_epochs=args.full_epochs, epochs_scale=args.epochs_scale, mixed_precision=args.mixed_precision or None,
        selection=args.selection, overrides=overrides, quick=args.quick, force=args.force,
        cross_targets=args.cross_targets, target_roots=target_roots, dg_targets=args.dg_targets, dg_shifts=args.dg_shifts,
        save_features=proto[0] != "base2new",
    )
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "main_config.json").write_text(json.dumps({**cfg, "tasks": tasks, "methods": methods, "seeds": args.seeds,
                                                       "shots": args.shots, "n_classes": n_cls, "protocol_task": proto[0],
                                                       "protocol_shots": proto[1], "argv": sys.argv}, indent=2))

    plan = build_plan(tasks, methods, args, n_cls)
    print(f"dataset {spec.name} ({n_cls} classes) at {spec.root}; {len(plan)} training/eval runs planned; out -> {out}")
    if args.dry_run:
        for p in plan:
            print("  ", p)
        return

    from mqa.engine import Engine

    eng = Engine(cfg)
    failures = []
    t0 = time.perf_counter()
    for task in tasks:
        if task == "topk":
            run_topk(eng, out)
        elif task == "efficiency":
            run_efficiency(eng, methods, out)
        elif task == "tsne":
            run_tsne(out, args.seeds[0], proto)
        elif task == "report":
            from mqa.engine.report import build_report

            print(f"\nreport -> {build_report(out)}")
        else:
            for p in [p for p in plan if p["task"] == task]:
                try:
                    eng.run(p["run_task"], p["method"], p["seed"], p.get("shots"), p.get("overrides"), p.get("variant", ""))
                except Exception as exc:  # noqa: BLE001
                    failures.append({**p, "error": repr(exc)})
                    print(f"!! failed {p}: {exc!r}", flush=True)
                    if not args.continue_on_error:
                        raise
    if failures:
        (out / "failures.json").write_text(json.dumps(failures, indent=2))
        print(f"{len(failures)} runs failed; see {out / 'failures.json'}")
    print(f"done in {(time.perf_counter() - t0) / 60:.1f} min")


def protocol_for(n_cls):
    """(task, shots) used for the paper's base-to-new analyses. Base-to-new needs >= 2 base classes (C >= 3);
    with 2 classes the 16-shot few-shot protocol replaces it."""
    if n_cls is not None and n_cls < 3:
        return ("fewshot", 16)
    return ("base2new", None)


def build_plan(tasks, methods, args, n_cls):
    plan = []
    ptask, pshots = protocol_for(n_cls)

    def proto(method, seed, **kw):
        d = {"run_task": ptask, "method": method, "seed": seed, **kw}
        if pshots:
            d["shots"] = pshots
        return d

    for task in tasks:
        if task in ("all", "base2new", "cross", "dg"):
            if task == "base2new" and ptask != "base2new":
                continue
            for m in methods:
                for s in args.seeds:
                    plan.append({"task": task, "run_task": task, "method": m, "seed": s})
        elif task == "fewshot":
            for m in methods:
                for sh in args.shots:
                    for s in args.seeds:
                        plan.append({"task": task, "run_task": "fewshot", "method": m, "seed": s, "shots": sh})
        elif task == "ablation":
            for s in args.seeds:
                plan.append({"task": task, **proto("mmrlpp", s)})
                plan.append({"task": task, **proto("mmrlpp+mqa", s)})
                for v, ov in ABLATION_VARIANTS.items():
                    plan.append({"task": task, **proto("mmrlpp+mqa", s, variant=v, overrides=ov)})
        elif task == "sweeps":
            s = args.seeds[0]
            kmax = ((n_cls + 1) // 2 if ptask == "base2new" else n_cls) if n_cls else 0
            for kk in SWEEP_K:
                if kmax and kk > kmax:
                    continue  # K larger than the number of (training) classes is the same run as K = that number
                plan.append({"task": task, **proto("mmrlpp+mqa", s, variant=f"k={kk}", overrides={"k": kk})})
            for g in SWEEP_GAMMA:
                plan.append({"task": task, **proto("mmrlpp+mqa", s, variant=f"gamma={g}", overrides={"gamma": g})})
            for st in SWEEP_START:
                plan.append({"task": task, **proto("mmrlpp+mqa", s, variant=f"start={st}", overrides={"adapt_layers": list(range(st, 12))})})
        elif task == "stability":
            for m in ("mmrlpp", "mmrlpp+mqa"):
                for s in sorted(set(args.seeds) | {1, 2, 3}):
                    plan.append({"task": task, **proto(m, s)})
    return plan


def run_topk(eng, out):
    from mqa.datasets import ClassSpace, resolve_classes, scan_split
    from mqa.engine.analysis import topk_analysis
    from mqa.hosts.factory import build_host, method_config

    clip, tok = eng.backbone()
    classes = resolve_classes(eng.spec)
    recs = scan_split(eng.spec, eng.spec.test_split, classes)
    if eng.cfg.get("quick"):
        recs = recs[:64]
    host = build_host("zeroshot", clip, tok, method_config("zeroshot"))
    res = topk_analysis(host, recs, ClassSpace(eng.spec, classes), eng.device, out / "topk", eng.cfg)
    print("Fig.1 Top-K accuracy:", {k: round(v, 2) for k, v in res["top_k_accuracy"].items()})


def run_efficiency(eng, methods, out):
    from mqa.datasets import ClassSpace, resolve_classes
    from mqa.engine.analysis import efficiency
    from mqa.hosts.factory import build_host

    clip, tok = eng.backbone()
    space = ClassSpace(eng.spec, resolve_classes(eng.spec))
    rows = []
    for m in methods:
        if m.startswith("linear_probe"):
            continue
        cfg = eng.run_config("base2new", m, None, None)
        host = build_host(m, clip, tok, cfg)
        r = efficiency(host, space, eng.device, batch_size=8 if eng.cfg.get("quick") else 100, iters=1 if eng.cfg.get("quick") else 5)
        rows.append({"method": m, **r})
        print(f"[efficiency] {m}: {r}")
        del host
    (out / "efficiency.json").write_text(json.dumps(rows, indent=2))


def run_tsne(out, seed, proto=("base2new", None)):
    from mqa.engine.analysis import tsne_figure

    files = {}
    ptask, pshots = proto
    for m in ("zeroshot", "mmrlpp", "mmrlpp+mqa"):
        if ptask == "base2new":
            d = out / "base2new" / m / "shotsall" / f"seed{seed}" / "eval"
            files[m] = {p: d / p / "features.npz" for p in ("base", "new")}
        else:  # binary: one test split, 16-shot runs (zero-shot CLIP is trained 0 steps, its features are frozen CLIP)
            d = out / ptask / m / f"shots{pshots}" / f"seed{seed}" / "eval"
            files[m] = {"test": d / "test" / "features.npz"}
    done = tsne_figure(files, out / "fig5_tsne.png", seed)
    print(f"Fig.5 t-SNE panels: {len(done)} -> {out / 'fig5_tsne.png'}")


if __name__ == "__main__":
    main()
