# MQAdapter for brain-tumour MRI detection (no / yes)

Paper-based reimplementation of **MQAdapter** (Zhao et al., arXiv:2607.12418v1) with all three host methods of the
paper (MaPLe, PromptSRC, MMRL++), the simple baselines (zero-shot CLIP, linear probe, CoOp, CoCoOp, CLIP-Adapter),
the evaluation protocols and the ablations/analyses, adapted to the Kaggle dataset
**[Brain MRI Images for Brain Tumor Detection](https://www.kaggle.com/datasets/navoneel/brain-mri-images-for-brain-tumor-detection)**
(Navoneel Chakrabarty; folders `no` and `yes`).

```text
python main.py --make-dummy-data data/dummy --backend fake --quick --seeds 1 --shots 1   # plumbing check, no downloads
python main.py                                                                          # the whole suite on the no/yes MRI data
```

* What changed for this dataset and how to read the results: **`docs/YESNO_ADAPTATION.md`**
* How to run, outputs, cost: `docs/RUNNING.md`; dataset specs and cross-dataset targets: `docs/DATASETS.md`
* Engine code: `mqa/hosts/` (methods), `mqa/engine/` (splits, trainer, evaluation, analyses, report)

### Binary dataset in one paragraph

The dataset has two classes and no train/test split. `scripts/download_dataset.py` downloads it, removes exact
duplicates (the archive contains every image twice) and label conflicts, keeps near-duplicates on one side, and
writes a seeded, stratified 80/20 split to `data/brain_mri_yesno/{Training,Testing}/{no,yes}` (optionally 5 folds).
With two classes, the paper's base-to-new protocol (Table I) is undefined and is skipped; the ablation (Table V),
sweeps (Fig. 3/4), stability (Table VI) and t-SNE (Fig. 5) use the 16-shot protocol instead. Top-K anchors: K = 2
(both classes) by default, K = 1 in the sweep. Every evaluation reports accuracy, balanced accuracy, sensitivity,
specificity and ROC-AUC (positive class `yes`).

## Run it from scratch

All steps, in order, on the training machine (NVIDIA GPU, ~12 GB is enough; Python 3.10-3.12).

### 1. Unpack and create an environment

```text
unzip mqadapter_brain_tumor_yesno.zip
cd mqadapter_brain_tumor
python -m venv .venv
source .venv/bin/activate              # Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

### 2. Install PyTorch (CUDA build) and the requirements

```text
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt
python -c "import torch; print(torch.__version__, 'CUDA available:', torch.cuda.is_available())"
```
The last line must print `CUDA available: True` (otherwise install the torch build for your driver; CPU works but is slow).

### 3. Check the code (1-2 minutes, no downloads)

```text
python -m pytest -q tests
```
Expected: all passed, 2 skipped (the TorchQuantum and real-CLIP tests skip when those are absent).

### 4. Download and prepare the dataset

**4a. Kaggle API token (once).** kaggle.com -> profile picture -> *Settings* -> *API* -> *Create New Token*, then
put `kaggle.json` in `~/.kaggle/` (Windows: `%USERPROFILE%\.kaggle\`), or set `KAGGLE_USERNAME` / `KAGGLE_KEY`.

**4b. Download + split** (one of):

```text
python scripts/download_dataset.py                                 # kagglehub, falls back to the Kaggle CLI
python scripts/download_dataset.py --method cli                    # Kaggle CLI only (pip install kaggle)
python scripts/download_dataset.py --zip ~/Downloads/archive.zip   # no token: click "Download" on the Kaggle page first
python scripts/download_dataset.py --folds 5                       # additionally data/brain_mri_yesno_fold0..4
```
It prints the counts (files seen, duplicates removed, images per class and split) and must end with `layout OK`.
Details are in `data/brain_mri_yesno/prepare_report.json`, the file list in `data/brain_mri_yesno/manifest.csv`.
Result:

```text
data/brain_mri_yesno/Training/{no,yes}/*
data/brain_mri_yesno/Testing/{no,yes}/*
```
Split options: `--test-ratio 0.2 --seed 0` (defaults). Re-running needs `--overwrite`.

**4c. (Optional) cross-dataset targets for Table III** - missing targets are skipped with a message:

```text
data/br35h/Testing/{no,yes}/*.jpg                                  # Br35H brain tumor detection 2020 (same labels)
python scripts/download_dataset.py --dataset nickparvar            # -> data/brain_tumor_mri (used as no/yes and as 4 classes)
data/figshare_brain/Testing/{glioma,meningioma,pituitary}/*.jpg    # Figshare (Cheng et al. 2017), exported to JPG
```

### 5. CLIP ViT-B/16 weights (once)

```text
python -c "import open_clip; open_clip.create_model_and_transforms('ViT-B-16', pretrained='openai', force_quick_gelu=True); print('CLIP ViT-B/16 weights cached')"
python main.py --tasks topk --no-download --out runs/check_clip        # offline check + paper Fig. 1 on this data
```

### 6. Plumbing check (fake CLIP, synthetic images, a few minutes on CPU)

```text
python main.py --make-dummy-data data/dummy --backend fake --quick --seeds 1 --shots 1 --out runs/smoke
```
Must finish with `report -> runs/smoke/REPORT.md` (numbers meaningless). On Windows add `--num-workers 0` if loading hangs.

### 7. Real experiments

```text
python main.py --dry-run                                           # list every run
python main.py --tasks topk fewshot report --seeds 1               # first real results (Table II, one seed)
python main.py                                                     # whole suite: Fig.1, Tables II-VII, Fig.3/4/5
python main.py --tasks all report --methods baselines hosts qvlm   # every training image (the practical result)
```
5-fold estimate (after `--folds 5`):
```text
for k in 0 1 2 3 4; do python main.py --data-root data/brain_mri_yesno_fold$k --out runs/fold$k --tasks topk all fewshot report; done
```
Finished runs are skipped, so you can stop and restart. Out of GPU memory: `--set batch_size=2 eval_batch_size=16`.

### 8. Results

* `runs/main/REPORT.md`: Tables II-VII (with sensitivity / specificity / AUC), Fig. 1/3/4 numbers, full-data table
* `runs/main/all_results.csv`: one row per run and evaluation set
* figures: `runs/main/fig5_tsne.png`, `runs/main/fig3_fig4_sweeps.png`, `runs/main/topk/fig1_topk.png`
* every run: `runs/main/<task>/<method>/shots*/seed*/` with `result.json`, metrics, `predictions.csv` (with p(no), p(yes)), confusion matrices

## Methods (`--methods`)

| name | what | paper role |
|---|---|---|
| `zeroshot` | frozen CLIP, hand prompts | "CLIP" row |
| `linear_probe` | logistic regression on frozen features | extra baseline |
| `clip_adapter`, `coop`, `cocoop` | classic fine-tuning | compared methods |
| `maple`, `promptsrc`, `mmrlpp` (`mmrl`) | the three host methods | hosts |
| `<any>+mqa` | same method with the MQAdapter plug-in | "+MQAdapter" rows |
| `zeroshot+mqa` | MQAdapter alone on frozen CLIP | extra |

## Tasks (`--tasks`)

`topk` (Fig. 1), `fewshot` (Table II), `cross` (Table III), `dg` (Table IV), `ablation` (Table V, 16-shot),
`sweeps` (Fig. 3/4, 16-shot), `stability` (Table VI, 16-shot), `efficiency` (Table VII), `tsne` (Fig. 5, 16-shot),
`report`, and `all` (every training image, not in the paper). `base2new` (Table I) exists for datasets with >= 3
classes (e.g. `--dataset brain_tumor_mri`) and is skipped for the no/yes data.

---

# Earlier single-run tooling (still works)


The scripts below (`scripts/train.py` & co.) predate `main.py`; they now use the no/yes classes
(`mqa.CLASS_NAMES = ("no", "yes")`) and `data/brain_mri_yesno`. There is no official MQAdapter code; the NumPy circuit in
`mqa/quantum/reference_paper_vqc.py` is the equation-level oracle (Eqs. 5-8).

* Is there a separate Q-VLM architecture in the paper? **No** - MQAdapter is the hybrid part. See `docs/Q_VLM_ANALYSIS.md`.
* What differs from the paper and what is unverified: `docs/COMPLIANCE.md`, `docs/LIMITATIONS.md`, `docs/IMPLEMENTATION_AUDIT.md`.

## Honest status

| Item | Status |
|---|---|
| NumPy VQC oracle (6 tests) | **executed, passed** |
| Protocol logic: all / base-to-new / few-shot (3 tests) | **executed, passed** (torch stubbed) |
| Cross-file import consistency, `py_compile` on every file | **executed, clean** |
| Everything that needs `torch` (VQC, adapter, all hosts, training, eval, `main.py` engine) | **executed with a fake CLIP on CPU**: `pytest -q tests` -> 68 passed, 2 skipped (torch 2.4.1). Not run with real CLIP weights, real MRI data or a GPU |
| TorchQuantum backend + parity test | **written, not executed**; test auto-skips without `torchquantum` |
| Real CLIP weights / Kaggle data / accuracy numbers | **none produced** - nothing here reports a result you did not generate |

If `pytest` shows a failure, that is a bug in my code, not in your setup - please report the traceback.

## What is implemented

| Paper component | Where |
|---|---|
| Frozen-CLIP Top-K semantic anchors (IV-A) | `retrieve_topk` in `MQAdapterCLIP`, `MaPLeCLIP` |
| Shared 8-qubit VQC (Eqs. 5-8): PyTorch statevector | `mqa/quantum/torch_vqc.py` |
| Same VQC in **TorchQuantum** (paper's library) | `mqa/quantum/tq_vqc.py` (`quantum_map: "tq_vqc"`) |
| Cross-modal quantum learning + residual injection (Eqs. 11-15) | `mqa/models/plugin.py`, `adapter.py` |
| Eq. 16 cosine cross-entropy | `forward` of every model |
| **MaPLe host** (deep coupled text/vision prompts) + MQAdapter on top | `mqa/models/maple.py` |
| Stand-alone MQAdapter on frozen CLIP | `mqa/models/mqadapter_clip.py` |
| Table V ablations: cross-attention, separate VQC; plus MLP / identity / frozen-random-VQC controls | `interaction`, `vqc_sharing`, `quantum_map` config keys |
| Few-shot (1/2/4/8/16), base-to-new (+ harmonic mean) | `mqa/protocols.py` |
| Fig. 1 Top-K analysis, Fig. 5 t-SNE, Table VI seeds, Table VII params/FPS, K / gamma / depth sweeps | `scripts/topk_analysis.py`, `tsne_features.py`, `run_seeds.py`, `efficiency.py`, `run_sweep.py` |
| One-command pipeline | `scripts/run_pipeline.py` |

PromptSRC, MMRL++, CoOp, CoCoOp, cross-dataset and domain generalisation are now in the `main.py` engine (see the top of this file).

## Bugs fixed in the earlier code

1. `visual_prefix` assumed sequence-first tokens. Recent `open_clip` is batch-first, which would have silently run attention across the batch and rewritten the wrong "class token". Now layout-aware (`run_block`, tested in `tests/test_layout.py`).
2. The VQC was only *documented* as fp32-safe; it now disables autocast internally.
3. `load_clip(download=False)` still downloaded; it now sets `HF_HUB_OFFLINE`. Configs default to `download_clip: true` (first run fetches ~350 MB).
4. The frozen CLIP could drift into train mode; models now keep it in `eval()`.
5. `best_val` was saved one epoch stale in checkpoints.

## Setup (12 GB GPU, 64 GB RAM)

```text
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt
# optional, the paper's quantum library (Python <= 3.11 is safest):  pip install torchquantum
python -m pytest -q tests
python scripts/download_dataset.py            # needs Kaggle credentials; or --zip archive.zip -> data/brain_mri_yesno
```

## Run

```text
python scripts/run_pipeline.py --stages env data inspect topk zeroshot --quick     # cheap plumbing check (no base2new stage: 2 classes)
python scripts/run_pipeline.py --stages all                                        # full run (hours)
```

Individual runs (Testing is read only with `--eval-after` or `scripts/evaluate.py`):

```text
python scripts/train.py --config configs/maple.json            --eval-after   # host only
python scripts/train.py --config configs/maple_mqadapter.json  --eval-after   # K=2 (both classes)
python scripts/train.py --config configs/maple_mqadapter_k1.json --eval-after  # K=1
python scripts/train.py --config configs/maple_mqadapter.json  --eval-after --set gamma=0.002
python scripts/run_seeds.py --config configs/maple_mqadapter.json --seeds 0 1 2
python scripts/run_sweep.py --sweep k gamma depth table5 --base configs/maple_mqadapter.json
python scripts/efficiency.py --configs configs/maple.json configs/maple_mqadapter.json
python scripts/tsne_features.py --checkpoint runs/maple_mqadapter_k2/best.pt
python scripts/summarize.py                                                    # runs/summary.md
```

**VRAM:** defaults are batch 16 (MaPLe) and 8 (stand-alone). These are my estimates, not measurements; on `CUDA out of memory` lower `batch_size` (`--set batch_size=8`).
`scripts/phase3_budget.py` measures real usage.

## Things to know before interpreting results

* **C = 2.** The paper uses K = 5 on datasets with up to 1000 classes. Here K in {1, 2}; K = 2 retrieves every class, so the coarse stage filters nothing.
* **gamma = 0.001 is tuned for hosts.** In the *stand-alone* adapter on frozen CLIP the residual `gamma * W f(h)` is tiny next to the class-token magnitude, so it may barely change predictions (my reasoning, not measured). Sweep gamma (`--sweep gamma`) and pick by validation loss.
* Pick sweep winners by `best_val_loss` in `train_summary.json`, never by Testing accuracy.
* The split is image-level (no patient IDs exist); do not claim patient-level generalisation.
* Quantum part is a **classical simulation** of 8 qubits; no quantum speed-up is implied.
