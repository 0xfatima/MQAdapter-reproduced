"""scripts/prepare_yesno_dataset.py on a synthetic copy of the Kaggle layout (no network)."""
import csv

import numpy as np
from PIL import Image

from scripts.prepare_yesno_dataset import prepare


def _img(seed, size=64):
    """Smooth random blobs (MRI-like low frequency content, so resizing keeps the difference hash)."""
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:size, 0:size] / size
    img = np.zeros((size, size))
    for _ in range(4):
        cx, cy, r, a = rng.random(4)
        img += a * np.exp(-(((xx - cx) ** 2 + (yy - cy) ** 2) / (2 * (0.05 + 0.2 * r) ** 2)))
    return Image.fromarray((img / img.max() * 255).astype(np.uint8), "L")


def _raw(tmp_path):
    raw = tmp_path / "archive"
    for top in (raw, raw / "brain_tumor_dataset"):  # the Kaggle zip ships every image twice
        for cls, n, off in (("no", 10, 0), ("yes", 15, 100)):
            d = top / cls
            d.mkdir(parents=True, exist_ok=True)
            for i in range(n):
                _img(off + i).save(d / f"{i} {cls}.jpg" if i % 3 else d / f"Y{i}.JPG", format="PNG")
    # near-duplicate of yes/0: same picture at another size (different bytes, same 16x16 dhash)
    big = _img(100).resize((128, 128), Image.BICUBIC)
    big.save(raw / "yes" / "dup_of_0.png")
    # label conflict: identical file in no/ and yes/
    _img(999).save(raw / "no" / "conflict.png")
    (raw / "yes" / "conflict.png").write_bytes((raw / "no" / "conflict.png").read_bytes())
    # unreadable
    (raw / "yes" / "broken.jpg").write_bytes(b"not an image")
    return raw


def test_prepare_dedup_split_and_folds(tmp_path):
    raw = _raw(tmp_path)
    dest = tmp_path / "out" / "brain_mri_yesno"
    rep = prepare(raw, dest, test_ratio=0.2, seed=0, folds=3)
    assert rep["near_duplicate_groups"] >= 1
    assert rep["exact_duplicates_removed"] >= 25          # the brain_tumor_dataset/ copy
    assert len(rep["label_conflicts_dropped"]) == 1
    assert len(rep["unreadable"]) == 1
    assert rep["unique_images"] == {"no": 10, "yes": 16}
    c = rep["split_counts"]
    assert c["Testing"]["no"] == 2 and c["Testing"]["yes"] in (3, 4)  # 20 %, a 2-image group may push yes to 4
    assert sum(c["Training"].values()) + sum(c["Testing"].values()) == 26
    rows = list(csv.DictReader(open(dest / "manifest.csv")))
    by_hash = {}
    for r in rows:
        by_hash.setdefault(r["dhash"], set()).add(r["split"])
    assert all(len(v) == 1 for v in by_hash.values())  # near-duplicates never straddle the split
    assert (dest / "Training" / "no").is_dir() and (dest / "Testing" / "yes").is_dir()
    tests = []
    for f in range(3):
        fd = tmp_path / "out" / f"brain_mri_yesno_fold{f}"
        tests += [p.name for p in (fd / "Testing").rglob("*.*")]
    assert len(tests) == len(set(tests)) == 26           # every image is tested exactly once over the folds
