from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from mqa.evaluation.metrics import classification_metrics, confusion_matrix_np
from mqa.models.clip_backbone import FakeCLIP, FakeTokenizer, encode_class_texts
from mqa.models.mqadapter_clip import MQAdapterCLIP
from mqa.training.checkpoint import load_checkpoint, save_checkpoint
from mqa.training.loop import train_model
from mqa.data.dataset import BrainTumorMRI
from mqa.data.preprocess import build_clip_transform
from PIL import Image
from torch.utils.data import DataLoader


def test_metrics_known_values():
    y_true = [0, 0, 1, 1, 2, 3]
    y_pred = [0, 1, 1, 1, 2, 0]
    m = classification_metrics(y_true, y_pred, ["a", "b", "c", "d"])
    assert m["n_samples"] == 6
    assert "sensitivity" not in m  # binary metrics only for two classes
    assert m["confusion_matrix"][0][0] == 1
    assert abs(m["accuracy"] - 4 / 6) < 1e-12
    cm = confusion_matrix_np(np.array(y_true), np.array(y_pred), 4)
    assert cm.shape == (4, 4)


def test_binary_metrics_known_values():
    # classes (no, yes); positive = yes. 3 tumours: 2 found; 3 healthy: 1 false alarm.
    y_true = [0, 0, 0, 1, 1, 1]
    y_pred = [0, 0, 1, 1, 1, 0]
    p_yes = [0.1, 0.2, 0.7, 0.9, 0.8, 0.3]
    probs = np.stack([1 - np.array(p_yes), np.array(p_yes)], 1)
    m = classification_metrics(y_true, y_pred, ["no", "yes"], probs=probs, positive="yes")
    assert m["tp"] == 2 and m["fn"] == 1 and m["tn"] == 2 and m["fp"] == 1
    assert abs(m["sensitivity"] - 2 / 3) < 1e-12 and abs(m["specificity"] - 2 / 3) < 1e-12
    assert abs(m["balanced_accuracy"] - 2 / 3) < 1e-12
    # AUC: pairs (pos, neg) where pos score > neg score: 0.9,0.8 beat all 3 negatives (6); 0.3 beats 0.1,0.2 (2) -> 8/9
    assert abs(m["roc_auc"] - 8 / 9) < 1e-12


def test_roc_auc_ties_and_degenerate():
    from mqa.evaluation.metrics import roc_auc_binary

    assert roc_auc_binary([0, 1], [0.5, 0.5]) == 0.5
    assert roc_auc_binary([1, 1], [0.2, 0.3]) is None


def test_checkpoint_roundtrip(tmp_path):
    clip = FakeCLIP()
    text = encode_class_texts(clip, FakeTokenizer())
    model = MQAdapterCLIP(clip, text, k=2)
    x = torch.randn(2, 3, 224, 224)
    before = model(x)["logits"].detach()
    path = tmp_path / "m.pt"
    save_checkpoint(path, {"model": model.state_dict(), "epoch": 3})
    clip2 = FakeCLIP()
    # different random init
    m2 = MQAdapterCLIP(clip2, text, k=2)
    m2.load_state_dict(load_checkpoint(path)["model"], strict=False)
    # clip weights also in state_dict; FakeCLIP was re-inited so strict load on same architecture:
    model2 = MQAdapterCLIP(FakeCLIP(), text, k=2)
    payload = load_checkpoint(path)
    model2.load_state_dict(payload["model"])
    after = model2(x)["logits"].detach()
    # images go through retrieved path; CLIP weights restored from ckpt so logits should match
    assert torch.allclose(before, after, atol=1e-5)
    assert payload["epoch"] == 3


def test_one_optimizer_epoch_smoke(tmp_path):
    root = tmp_path / "data"
    recs = []
    for i, cls in enumerate(["no", "yes"]):
        d = root / cls
        d.mkdir(parents=True)
        for j in range(2):
            p = d / f"{j}.png"
            Image.new("RGB", (64, 64), color=(i * 120, 10, 10)).save(p)
            recs.append({"path": str(p), "class": cls, "label": i})
    ds = BrainTumorMRI(recs, transform=build_clip_transform(False))
    loader = DataLoader(ds, batch_size=4)
    clip = FakeCLIP()
    text = encode_class_texts(clip, FakeTokenizer())
    model = MQAdapterCLIP(clip, text, k=2)
    summary = train_model(
        model,
        loader,
        loader,
        ["no", "yes"],
        out_dir=tmp_path / "run",
        epochs=1,
        lr=1e-3,
        device="cpu",
        seed=0,
        patience=2,
        max_steps=1,
    )
    assert summary["trained"] is True
    assert (tmp_path / "run" / "last.pt").exists()
