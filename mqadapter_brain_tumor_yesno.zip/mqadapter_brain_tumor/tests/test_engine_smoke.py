"""main.py's engine end to end on synthetic folders with FakeCLIP (plumbing only; numbers are meaningless)."""
import json

import pytest

torch = pytest.importorskip("torch")

from mqa.engine import Engine  # noqa: E402
from mqa.engine.report import build_report  # noqa: E402
from scripts.make_dummy_dataset import make_all  # noqa: E402

TARGETS = ["br35h", "brain_tumor_mri_binary", "figshare_brain"]


@pytest.fixture(scope="module")
def roots(tmp_path_factory):
    return make_all(tmp_path_factory.mktemp("data"))


@pytest.fixture(scope="module")
def engine(roots, tmp_path_factory):
    out = tmp_path_factory.mktemp("runs")
    cfg = dict(dataset="brain_mri_yesno", data_root=str(roots["brain_mri_yesno"]), backend="fake", device="cpu", out_root=str(out),
               augment="mri", num_workers=0, quick=True, quick_steps=2, overrides={"k": 2, "eval_batch_size": 8}, save_features=True,
               cross_targets=TARGETS, target_roots={"br35h": str(roots["br35h"]), "figshare_brain": str(roots["figshare_brain"]),
                                                    "brain_tumor_mri_binary": str(roots["brain_tumor_mri"])})
    return Engine(cfg), out


@pytest.mark.parametrize("task,method,shots", [
    ("fewshot", "zeroshot", 16), ("fewshot", "mmrlpp", 16), ("fewshot", "mmrlpp+mqa", 16), ("fewshot", "maple+mqa", 2),
    ("cross", "promptsrc+mqa", None), ("dg", "coop", None), ("all", "linear_probe", None), ("all", "zeroshot+mqa", None),
])
def test_engine_tasks_binary(engine, task, method, shots):
    eng, out = engine
    r = eng.run(task, method, seed=1, shots=shots)
    assert r["evals"], r
    assert r["classes"] == ["no", "yes"]
    if task in ("fewshot", "all"):
        s = r["summary"]
        assert s["accuracy"] is not None and s["sensitivity"] is not None and s["specificity"] is not None
        assert s["roc_auc"] is not None and 0 <= s["roc_auc"] <= 100
    if task == "cross":
        assert set(r["summary"]["targets"]) == set(TARGETS)
        assert r["evals"]["br35h"]["mode"] == "base"            # same no/yes label space -> domain shift
        assert r["evals"]["figshare_brain"]["mode"] == "novel"  # other classes -> unseen label space
        assert r["evals"]["brain_tumor_mri_binary"]["n_samples"] > 0
    if task == "fewshot" and shots == 16:
        assert (out / "fewshot" / method / "shots16" / "seed1" / "eval" / "test" / "features.npz").exists()


def test_base2new_refused_for_binary(engine):
    eng, _ = engine
    with pytest.raises(SystemExit, match="at least 3 classes"):
        eng.run("base2new", "zeroshot", seed=1)


def test_ablation_variant_on_fewshot(engine):
    eng, _ = engine
    r = eng.run("fewshot", "mmrlpp+mqa", seed=1, shots=16, overrides={"interaction": "cross_attention"}, variant="cross_attention")
    assert r["variant"] == "cross_attention" and r["summary"]["accuracy"] is not None


def test_report_binary(engine):
    eng, out = engine
    text = build_report(out).read_text()
    assert "Table I -" not in text and "Table V" in text and "AUC" in text
    assert "Baseline+cross-attention" in text
    assert (out / "all_results.csv").exists()
    json.loads(next(out.glob("**/result.json")).read_text())


def test_tsne_binary(engine):
    from main import run_tsne

    _, out = engine
    run_tsne(out, 1, ("fewshot", 16))
    assert (out / "fig5_tsne.png").exists()


def test_base2new_still_works_for_multiclass(roots, tmp_path):
    cfg = dict(dataset="brain_tumor_mri", data_root=str(roots["brain_tumor_mri"]), backend="fake", device="cpu", out_root=str(tmp_path),
               augment="mri", num_workers=0, quick=True, quick_steps=2, overrides={"k": 2, "eval_batch_size": 8})
    r = Engine(cfg).run("base2new", "mmrlpp+mqa", seed=1)
    assert r["summary"]["H"] is not None
