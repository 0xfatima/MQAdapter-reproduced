from __future__ import annotations

from pathlib import Path

from PIL import Image

from mqa import CLASS_NAMES
from mqa.protocols import build_protocol, class_halves


def _tree(root: Path, n_train=8, n_test=3):
    for split, n in (("Training", n_train), ("Testing", n_test)):
        for cls in CLASS_NAMES:
            d = root / split / cls
            d.mkdir(parents=True, exist_ok=True)
            for i in range(n):
                Image.new("L", (20, 20), color=i).save(d / f"{cls}_{i}.png")


def test_all_protocol(tmp_path):
    _tree(tmp_path)
    p = build_protocol({"protocol": "all", "val_ratio": 0.25, "seed": 0}, tmp_path)
    assert p["train_classes"] == [0, 1]
    assert len(p["train"]) + len(p["val"]) == 8 * len(CLASS_NAMES)
    assert len(p["eval_records"]["all"]) == 6
    assert not ({r["path"] for r in p["train"]} & {r["path"] for r in p["eval_records"]["all"]})


def test_base_to_new_rejected_for_binary(tmp_path):
    """no/yes has 2 classes: base-to-new would train on one class, so it must refuse."""
    import pytest

    _tree(tmp_path)
    with pytest.raises(ValueError, match="base-to-new"):
        build_protocol({"protocol": "base2new", "val_ratio": 0.25, "seed": 0}, tmp_path)


def test_fewshot(tmp_path):
    _tree(tmp_path, n_train=20)
    p = build_protocol({"protocol": "all", "shots": 4, "val_ratio": 0.25, "seed": 1}, tmp_path)
    assert len(p["train"]) + len(p["val"]) == 4 * len(CLASS_NAMES)
