"""Real open_clip architecture (random weights, no download): layout detection and tower equivalence.

Guards against the open_clip 4.x regression where `transformer.batch_first` disappeared and the towers were run in
the wrong layout (crash in the text tower, silent batch mixing in the vision tower).
"""
import pytest

torch = pytest.importorskip("torch")
open_clip = pytest.importorskip("open_clip")

import torch.nn as nn  # noqa: E402
import torch.nn.functional as F  # noqa: E402

from mqa.datasets import ClassSpace, load_spec  # noqa: E402
from mqa.hosts.factory import build_host, is_trainable, method_config  # noqa: E402
from mqa.models.clip_backbone import probe_block_batch_first, transformer_batch_first  # noqa: E402


@pytest.fixture(scope="module")
def oc():
    torch.manual_seed(0)
    model, _, _ = open_clip.create_model_and_transforms("ViT-B-16", pretrained=None)
    model.eval()
    for p in model.parameters():
        p.requires_grad = False
    return model, open_clip.get_tokenizer("ViT-B-16")


def test_probe_detects_both_layouts(oc):
    model, _ = oc
    assert transformer_batch_first(model.visual.transformer) is True
    assert transformer_batch_first(model.transformer) is True
    seq_first = nn.TransformerEncoderLayer(64, 4, 128, dropout=0.0, batch_first=False)
    batch_first = nn.TransformerEncoderLayer(64, 4, 128, dropout=0.0, batch_first=True)
    assert probe_block_batch_first(seq_first) is False
    assert probe_block_batch_first(batch_first) is True


def test_towers_match_open_clip(oc):
    model, tok = oc
    host = build_host("zeroshot", model, tok, method_config("zeroshot", {"k": 2}))
    x = torch.randn(3, 3, 224, 224)
    with torch.no_grad():
        ref = model.encode_image(x)
        tokens, _ = host.run_visual(x)
        mine = host.pool_visual(tokens)
    assert torch.allclose(ref, mine, atol=1e-4, rtol=1e-4)
    # images must not influence each other
    with torch.no_grad():
        alone = host.pool_visual(host.run_visual(x[:1])[0])
    assert torch.allclose(alone, mine[:1], atol=1e-4, rtol=1e-4)
    texts = ["An MRI scan showing a brain tumor.", "An MRI scan showing a healthy brain with no tumor."]
    t = tok(texts)
    with torch.no_grad():
        ref_t = F.normalize(model.encode_text(t).float(), dim=-1)
        emb = model.token_embedding(t).float()
        mine_t = host.run_text(emb, t.argmax(dim=-1))
    assert torch.allclose(ref_t, mine_t, atol=1e-4, rtol=1e-4)


@pytest.mark.parametrize("name", ["coop", "cocoop", "maple", "promptsrc", "mmrlpp", "zeroshot+mqa", "maple+mqa",
                                  "promptsrc+mqa", "mmrlpp+mqa"])
def test_hosts_run_on_open_clip(oc, name):
    model, tok = oc
    host = build_host(name, model, tok, method_config(name, {"k": 2}))
    host.set_class_space(ClassSpace(load_spec("brain_mri_yesno"), ["no", "yes"]), "base")
    x, y = torch.randn(2, 3, 224, 224), torch.tensor([0, 1])
    out = host.train()(x, y)
    assert out["logits"].shape == (2, 2) and torch.isfinite(out["loss"])
    if is_trainable(name):
        out["loss"].backward()
        assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in host.parameters() if p.requires_grad)
    host.eval()
    with torch.no_grad():
        host.set_class_space(ClassSpace(load_spec("brain_tumor_mri"), ["glioma", "meningioma", "notumor", "pituitary"]), "novel")
        assert host(x)["logits"].shape == (2, 4)


def test_openai_loader_uses_quick_gelu(monkeypatch):
    """create_openai_vit_b16 must ask open_clip for QuickGELU (checked without downloading weights)."""
    from mqa.models import clip_backbone

    seen = {}
    real_create = open_clip.create_model_and_transforms

    def fake_create(name, pretrained=None, **kw):
        seen.update(kw, name=name, pretrained=pretrained)
        return real_create(name, pretrained=None, **kw)

    monkeypatch.setattr(open_clip, "create_model_and_transforms", fake_create)
    model, _, _ = clip_backbone.create_openai_vit_b16(open_clip)
    assert seen["force_quick_gelu"] is True and seen["pretrained"] == "openai"
    assert type(model.visual.transformer.resblocks[0].mlp.gelu).__name__ == "QuickGELU"
