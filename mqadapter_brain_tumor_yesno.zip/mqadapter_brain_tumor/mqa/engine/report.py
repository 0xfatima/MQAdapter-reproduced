"""Collect <out_root>/**/result.json into the paper's tables (markdown + CSV + JSON).

  Table I    base-to-new (Base / New / H) with the Δ of each "+mqa" row over its host
  Table II   few-shot accuracy for 1/2/4/8/16 shots
  Table III  cross-dataset transfer
  Table IV   domain generalisation
  Table V    ablation on MMRL++ (cross-attention / separate VQC / MQAdapter; plus our extra controls)
  Table VI   training stability (mean ± std over seeds)
  Table VII  efficiency (params, FPS)
  Fig. 3/4   K, gamma and insertion-depth sweeps
  Full data  every training image (not in the paper; the practical MRI result)

Binary datasets (the yes/no MRI set): Table I does not exist (base-to-new needs >= 3 classes). Tables V/VI and
the Fig. 3/4 sweeps are built from the 16-shot runs instead and show accuracy, balanced accuracy, sensitivity,
specificity and ROC-AUC (positive class = "yes").
Only numbers present in result files are reported; missing cells are "-".
"""
from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

ORDER = ["zeroshot", "linear_probe", "clip_adapter", "coop", "cocoop", "zeroshot+mqa", "coop+mqa", "maple", "maple+mqa",
         "promptsrc", "promptsrc+mqa", "mmrl", "mmrl+mqa", "mmrlpp", "mmrlpp+mqa"]
LABEL = {"zeroshot": "CLIP (zero-shot)", "zeroshot+mqa": "MQAdapter (stand-alone)", "linear_probe": "Linear probe",
         "clip_adapter": "CLIP-Adapter", "coop": "CoOp", "cocoop": "CoCoOp", "maple": "MaPLe", "promptsrc": "PromptSRC",
         "mmrl": "MMRL", "mmrlpp": "MMRL++"}


def label(m: str) -> str:
    if m in LABEL:
        return LABEL[m]
    base = m.split("+")[0]
    return f"{LABEL.get(base, base)} + MQAdapter" if m.endswith("+mqa") else m


def load_results(root: Path) -> list[dict]:
    out = []
    for p in sorted(root.glob("**/result.json")):
        try:
            out.append(json.loads(p.read_text()))
        except Exception:
            pass
    return out


def _ms(vals):
    v = [x for x in vals if x is not None]
    if not v:
        return None, None, 0
    return float(np.mean(v)), (float(np.std(v)) if len(v) > 1 else 0.0), len(v)


def f(x, p=2):
    return "-" if x is None else f"{x:.{p}f}"


def _sorted_methods(ms):
    return sorted(ms, key=lambda m: (ORDER.index(m) if m in ORDER else 99, m))


def _md(headers, rows):
    lines = ["| " + " | ".join(headers) + " |", "|" + "---|" * len(headers)]
    lines += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(lines)


def group(results, task, variant=""):
    g = defaultdict(list)
    for r in results:
        if r["task"] == task and (r.get("variant") or "") == variant:
            g[(r["method"], r.get("shots"))].append(r)
    return g


def table_base2new(results):
    g = group(results, "base2new")
    rows, data = [], {}
    for m in _sorted_methods({k[0] for k in g}):
        rs = [r for (mm, _), v in g.items() if mm == m for r in v]
        b, sb, n = _ms([r["summary"]["base"] for r in rs])
        nn_, sn, _ = _ms([r["summary"]["new"] for r in rs])
        h, sh, _ = _ms([r["summary"]["H"] for r in rs])
        data[m] = (b, nn_, h)
        rows.append([label(m), f(b), f(nn_), f(h), n])
        host = m.split("+")[0]
        if m.endswith("+mqa") and host in data and host != "zeroshot":
            hb, hn, hh = data[host]
            d = lambda a, c: "-" if a is None or c is None else f"({a - c:+.2f})"  # noqa: E731
            rows.append(["Δ", d(b, hb), d(nn_, hn), d(h, hh), ""])
    return _md(["Method", "Base", "New", "H", "seeds"], rows), data


def table_fewshot(results):
    g = group(results, "fewshot")
    shots = sorted({k[1] for k in g if k[1]})
    rows, data = [], {}
    for m in _sorted_methods({k[0] for k in g}):
        accs = []
        for s in shots:
            mean, _, _ = _ms([r["summary"]["accuracy"] for r in g.get((m, s), [])])
            accs.append(mean)
        data[m] = accs
        rows.append([label(m)] + [f(a) for a in accs])
        host = m.split("+")[0]
        if m.endswith("+mqa") and host in data and host != "zeroshot":
            rows.append(["Δ"] + ["-" if a is None or b is None else f"({a - b:+.2f})" for a, b in zip(accs, data[host])])
    return _md(["Method"] + [f"{s}-shot" for s in shots], rows), data


def table_transfer(results, task):
    g = group(results, task)
    targets = []
    for v in g.values():
        for r in v:
            for t in r["summary"].get("targets", {}):
                if t not in targets:
                    targets.append(t)
    rows = []
    for m in _sorted_methods({k[0] for k in g}):
        rs = [r for (mm, _), v in g.items() if mm == m for r in v]
        src, _, n = _ms([r["summary"]["source"] for r in rs])
        avg, _, _ = _ms([r["summary"]["target_avg"] for r in rs])
        cells = [f(_ms([r["summary"]["targets"].get(t) for r in rs])[0]) for t in targets]
        rows.append([label(m), f(src), f(avg)] + cells)
    return _md(["Method", "Source", "Target avg"] + targets, rows)


def table_variants(results, task, method_prefix, title_map):
    """Baseline host, host+MQAdapter and the named ablation variants only (sweep variants are excluded)."""
    rows = []
    g = defaultdict(list)
    for r in results:
        v = r.get("variant") or ""
        if r["task"] == task and r["method"].split("+")[0] == method_prefix and (v == "" or v in title_map):
            g[(r["method"], v)].append(r)
    for (m, v), rs in sorted(g.items(), key=lambda kv: (kv[0][1] != "", kv[0][0].endswith("+mqa"), kv[0][1])):
        b, _, n = _ms([r["summary"]["base"] for r in rs])
        nn_, _, _ = _ms([r["summary"]["new"] for r in rs])
        h, _, _ = _ms([r["summary"]["H"] for r in rs])
        name = title_map[v] if v else ("Baseline+MQAdapter" if m.endswith("+mqa") else "Baseline")
        rows.append([name, f(b), f(nn_), f(h), n])
    return _md(["Method", "Base", "New", "H", "seeds"], rows)


def table_stability(results, methods=("mmrlpp", "mmrlpp+mqa")):
    rows = []
    for m in methods:
        rs = [r for r in results if r["task"] == "base2new" and r["method"] == m and not r.get("variant")]
        b, sb, n = _ms([r["summary"]["base"] for r in rs])
        nn_, sn, _ = _ms([r["summary"]["new"] for r in rs])
        rows.append([label(m) if not m.endswith("+mqa") else "+MQAdapter", f"{f(b)} ± {f(sb)}", f"{f(nn_)} ± {f(sn)}", n])
    return _md(["Method", "Base", "New", "seeds"], rows)


def table_sweep(results, key):
    g = defaultdict(list)
    for r in results:
        v = r.get("variant") or ""
        if r["task"] == "base2new" and v.startswith(key + "="):
            g[v].append(r)
    pts = []
    for v, rs in g.items():
        x = float(v.split("=", 1)[1])
        pts.append((x, _ms([r["summary"]["base"] for r in rs])[0], _ms([r["summary"]["new"] for r in rs])[0], _ms([r["summary"]["H"] for r in rs])[0]))
    pts.sort()
    return _md([key, "Base", "New", "H"], [[f"{p[0]:g}", f(p[1]), f(p[2]), f(p[3])] for p in pts]), pts


def plot_sweeps(sweeps: dict, out: Path, labels=("Base", "New", "H")):
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return
    items = [(k, v) for k, v in sweeps.items() if v]
    if not items:
        return
    fig, axes = plt.subplots(1, len(items), figsize=(4.2 * len(items), 3.3), squeeze=False)
    for ax, (k, pts) in zip(axes[0], items):
        xs = list(range(len(pts)))
        for j, (lab, mk) in enumerate(zip(labels, ("+", "o", "o"))):
            ax.plot(xs, [p[j + 1] for p in pts], marker=mk, label=lab)
        ax.set_xticks(xs, [f"{p[0]:g}" for p in pts])
        ax.set_title(k)
        ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)



# ----------------------------------------------------------------------------- binary / few-shot protocol tables
BIN_COLS = [("accuracy", "Acc"), ("balanced_accuracy", "Bal. acc"), ("sensitivity", "Sens"), ("specificity", "Spec"),
            ("roc_auc", "AUC"), ("macro_f1", "Macro-F1")]


def _metric(r, key):
    v = r["summary"].get(key)
    if key == "macro_f1" and v is not None:
        return v * 100
    return v


def _proto_rows(results, task, shots, method_prefix, variant_filter):
    g = defaultdict(list)
    for r in results:
        v = r.get("variant") or ""
        if r["task"] == task and r.get("shots") == shots and r["method"].split("+")[0] == method_prefix and variant_filter(v):
            g[(r["method"], v)].append(r)
    return g


def table_variants_fs(results, task, shots, method_prefix, title_map):
    g = _proto_rows(results, task, shots, method_prefix, lambda v: v == "" or v in title_map)
    rows = []
    for (m, v), rs in sorted(g.items(), key=lambda kv: (kv[0][1] != "", kv[0][0].endswith("+mqa"), kv[0][1])):
        name = title_map[v] if v else ("Baseline+MQAdapter" if m.endswith("+mqa") else "Baseline")
        rows.append([name] + [f(_ms([_metric(r, k) for r in rs])[0]) for k, _ in BIN_COLS] + [len(rs)])
    return _md(["Method"] + [c for _, c in BIN_COLS] + ["seeds"], rows)


def table_stability_fs(results, task, shots, methods=("mmrlpp", "mmrlpp+mqa")):
    rows = []
    for m in methods:
        rs = [r for r in results if r["task"] == task and r.get("shots") == shots and r["method"] == m and not r.get("variant")]
        cells = []
        for k, _ in BIN_COLS[:5]:
            mean, sd, _ = _ms([_metric(r, k) for r in rs])
            cells.append(f"{f(mean)} ± {f(sd)}")
        rows.append([label(m) if not m.endswith("+mqa") else "+MQAdapter"] + cells + [len(rs)])
    return _md(["Method"] + [c for _, c in BIN_COLS[:5]] + ["seeds"], rows)


def table_sweep_fs(results, task, shots, key):
    g = defaultdict(list)
    for r in results:
        v = r.get("variant") or ""
        if r["task"] == task and r.get("shots") == shots and v.startswith(key + "="):
            g[v].append(r)
    pts = []
    for v, rs in g.items():
        x = float(v.split("=", 1)[1])
        pts.append((x, _ms([_metric(r, "accuracy") for r in rs])[0], _ms([_metric(r, "balanced_accuracy") for r in rs])[0],
                    _ms([_metric(r, "roc_auc") for r in rs])[0]))
    pts.sort()
    return _md([key, "Acc", "Bal. acc", "AUC"], [[f"{p[0]:g}", f(p[1]), f(p[2]), f(p[3])] for p in pts]), pts


def table_fewshot_metric(results, key):
    g = group(results, "fewshot")
    shots = sorted({k[1] for k in g if k[1]})
    rows = []
    for m in _sorted_methods({k[0] for k in g}):
        rows.append([label(m)] + [f(_ms([_metric(r, key) for r in g.get((m, sh), [])])[0]) for sh in shots])
    return _md(["Method"] + [f"{sh}-shot" for sh in shots], rows)


def _protocol(root: Path, results) -> tuple[str, int | None]:
    cfgp = root / "main_config.json"
    if cfgp.exists():
        try:
            c = json.loads(cfgp.read_text())
            if c.get("protocol_task"):
                return c["protocol_task"], c.get("protocol_shots")
        except Exception:
            pass
    if any(r["task"] == "base2new" for r in results):
        return "base2new", None
    return "fewshot", 16


ABLATION_TITLES = {"cross_attention": "Baseline+cross-attention", "separate_vqc": "Baseline+separate VQC",
                   "mlp": "Baseline+MLP instead of VQC (extra)", "identity": "Baseline+no VQC (extra)",
                   "frozen_vqc": "Baseline+frozen random VQC (extra)"}


def build_report(root: Path) -> Path:
    results = load_results(root)
    parts = [f"# Results ({len(results)} runs under `{root}`)\n",
             "All accuracies in %. Means over the seeds that exist on disk. '-' = not run.\n"]
    ptask, pshots = _protocol(root, results)
    binary = ptask != "base2new"
    if binary:
        parts += [f"Binary dataset: Table I (base-to-new) is undefined; Tables V/VI and Fig. 3/4 use the {pshots}-shot runs. "
                  "Sens = sensitivity (recall of 'yes'), Spec = specificity (recall of 'no'), AUC = ROC-AUC of p(yes).\n"]
    else:
        t1, _ = table_base2new(results)
        parts += ["## Table I - base-to-new generalisation\n", t1, ""]
    t2, _ = table_fewshot(results)
    parts += ["## Table II - few-shot classification (accuracy)\n", t2, ""]
    if any(r["task"] == "fewshot" and r["summary"].get("roc_auc") is not None for r in results):
        parts += ["## Table II-b - few-shot ROC-AUC\n", table_fewshot_metric(results, "roc_auc"), "",
                  "## Table II-c - few-shot balanced accuracy\n", table_fewshot_metric(results, "balanced_accuracy"), ""]
    parts += ["## Table III - cross-dataset transfer\n", table_transfer(results, "cross"), ""]
    parts += ["## Table IV - domain generalisation\n", table_transfer(results, "dg"), ""]
    sweeps = {}
    if binary:
        parts += [f"## Table V - ablation (MMRL++ host, {pshots}-shot)\n", table_variants_fs(results, ptask, pshots, "mmrlpp", ABLATION_TITLES), ""]
        parts += [f"## Table VI - training stability ({pshots}-shot)\n", table_stability_fs(results, ptask, pshots), ""]
        for key, title in (("k", "Fig. 3(a) Top-K"), ("gamma", "Fig. 3(b) gamma"), ("start", "Fig. 4 insertion start block (0-indexed)")):
            t, pts = table_sweep_fs(results, ptask, pshots, key)
            sweeps[title] = pts
            parts += [f"## {title} ({pshots}-shot)\n", t, ""]
    else:
        parts += ["## Table V - ablation (MMRL++ host)\n", table_variants(results, "base2new", "mmrlpp", ABLATION_TITLES), ""]
        parts += ["## Table VI - training stability\n", table_stability(results), ""]
        for key, title in (("k", "Fig. 3(a) Top-K"), ("gamma", "Fig. 3(b) gamma"), ("start", "Fig. 4 insertion start block (0-indexed)")):
            t, pts = table_sweep(results, key)
            sweeps[title] = pts
            parts += [f"## {title}\n", t, ""]
    plot_sweeps(sweeps, root / "fig3_fig4_sweeps.png", ("Acc", "Bal. acc", "AUC") if binary else ("Base", "New", "H"))
    eff = root / "efficiency.json"
    if eff.exists():
        rows = [[label(r["method"]), r["trainable_params"], r["mqadapter_params"], r["vqc_params"], f(r["fps"], 1)] for r in json.loads(eff.read_text())]
        parts += ["## Table VII - efficiency\n", _md(["Method", "Trainable params", "MQAdapter params", "VQC params", "FPS (bs 100)"], rows), ""]
    ga = group(results, "all")
    if ga:
        rows = []
        for m in _sorted_methods({k[0] for k in ga}):
            rs = [r for (mm, _), v in ga.items() if mm == m for r in v]
            a, sa, n = _ms([r["summary"]["accuracy"] for r in rs])
            mf, _, _ = _ms([_metric(r, "macro_f1") for r in rs])
            extra = [f(_ms([_metric(r, k) for r in rs])[0]) for k in ("balanced_accuracy", "sensitivity", "specificity", "roc_auc")]
            rows.append([label(m), f"{f(a)} ± {f(sa)}", f(mf)] + extra + [n])
        parts += ["## Full training data (not in the paper)\n",
                  _md(["Method", "Accuracy", "Macro-F1", "Bal. acc", "Sens", "Spec", "AUC", "seeds"], rows), ""]
    topk = root / "topk" / "topk_analysis.json"
    if topk.exists():
        t = json.loads(topk.read_text())
        parts += ["## Fig. 1 - frozen CLIP Top-K accuracy\n", _md(list(t["top_k_accuracy"].keys()) + ["mean sim"],
                  [[f(v) for v in t["top_k_accuracy"].values()] + [f(t["mean_similarity_topk"], 4)]]), ""]
    out = root / "REPORT.md"
    out.write_text("\n".join(parts), encoding="utf-8")
    with open(root / "all_results.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        pc = lambda v, k: None if v.get(k) is None else round(v[k] * 100, 3)  # noqa: E731
        w.writerow(["task", "method", "variant", "shots", "seed", "eval_set", "accuracy", "macro_f1", "balanced_accuracy",
                    "sensitivity", "specificity", "roc_auc", "topk_recall", "trainable_params"])
        for r in results:
            for k, v in r["evals"].items():
                w.writerow([r["task"], r["method"], r.get("variant"), r.get("shots"), r["seed"], k, pc(v, "accuracy"), pc(v, "macro_f1"),
                            pc(v, "balanced_accuracy"), pc(v, "sensitivity"), pc(v, "specificity"), pc(v, "roc_auc"),
                            v.get("coarse_topk_recall"), r.get("trainable_params")])
    return out
