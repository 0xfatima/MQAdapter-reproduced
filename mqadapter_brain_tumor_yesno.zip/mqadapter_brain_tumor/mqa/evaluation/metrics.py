from __future__ import annotations

from typing import Sequence

import numpy as np

from mqa import CLASS_NAMES


def confusion_matrix_np(y_true: np.ndarray, y_pred: np.ndarray, n_classes: int) -> np.ndarray:
    cm = np.zeros((n_classes, n_classes), dtype=np.int64)
    for t, p in zip(y_true.astype(int), y_pred.astype(int)):
        if 0 <= t < n_classes and 0 <= p < n_classes:
            cm[t, p] += 1
    return cm


def _prf(tp: int, fp: int, fn: int) -> tuple[float, float, float]:
    prec = tp / (tp + fp) if (tp + fp) else 0.0
    rec = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
    return prec, rec, f1


def roc_auc_binary(y_true: Sequence[int], scores: Sequence[float]) -> float | None:
    """ROC-AUC for labels in {0,1} via the Mann-Whitney U statistic (ties get half credit). None if one class is absent."""
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(scores, dtype=float)
    pos, neg = s[y == 1], s[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return None
    order = np.argsort(np.concatenate([pos, neg]), kind="mergesort")
    allv = np.concatenate([pos, neg])[order]
    ranks = np.empty(len(allv))
    i = 0
    while i < len(allv):  # average ranks over ties
        j = i
        while j + 1 < len(allv) and allv[j + 1] == allv[i]:
            j += 1
        ranks[i : j + 1] = (i + j) / 2.0 + 1.0
        i = j + 1
    r = np.empty(len(allv))
    r[order] = ranks
    r_pos = r[: len(pos)].sum()
    return float((r_pos - len(pos) * (len(pos) + 1) / 2.0) / (len(pos) * len(neg)))


def binary_metrics(cm: np.ndarray, pos: int, y_true=None, scores=None) -> dict:
    """Sensitivity / specificity / PPV / NPV of a 2x2 confusion matrix with `pos` the positive class index."""
    neg = 1 - pos
    tp, fn = int(cm[pos, pos]), int(cm[pos, neg])
    tn, fp = int(cm[neg, neg]), int(cm[neg, pos])
    sens = tp / (tp + fn) if tp + fn else None
    spec = tn / (tn + fp) if tn + fp else None
    out = {
        "positive_class_index": pos,
        "tp": tp, "fn": fn, "tn": tn, "fp": fp,
        "sensitivity": sens,
        "specificity": spec,
        "ppv": tp / (tp + fp) if tp + fp else None,
        "npv": tn / (tn + fn) if tn + fn else None,
    }
    if y_true is not None and scores is not None:
        yb = (np.asarray(y_true, dtype=int) == pos).astype(int)
        out["roc_auc"] = roc_auc_binary(yb, scores)
    return out


def classification_metrics(
    y_true: Sequence[int],
    y_pred: Sequence[int],
    class_names: Sequence[str] = CLASS_NAMES,
    probs: np.ndarray | None = None,
    positive: str | None = None,
) -> dict:
    """Accuracy, macro P/R/F1, balanced accuracy, confusion matrix; for two classes with a known positive
    class also sensitivity, specificity, PPV, NPV and (if `probs` [N, 2] is given) ROC-AUC."""
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    n = len(class_names)
    cm = confusion_matrix_np(y_true, y_pred, n)
    support = cm.sum(axis=1)
    per = {}
    precs, recs, f1s = [], [], []
    for i, name in enumerate(class_names):
        tp = int(cm[i, i])
        fp = int(cm[:, i].sum() - tp)
        fn = int(cm[i, :].sum() - tp)
        p, r, f = _prf(tp, fp, fn)
        per[name] = {"precision": p, "recall": r, "f1": f, "support": int(support[i])}
        precs.append(p)
        recs.append(r)
        f1s.append(f)
    acc = float((y_true == y_pred).mean()) if len(y_true) else 0.0
    present = [r for r, sup in zip(recs, support) if sup > 0]
    out = {
        "accuracy": acc,
        "balanced_accuracy": float(np.mean(present)) if present else 0.0,
        "macro_precision": float(np.mean(precs)) if precs else 0.0,
        "macro_recall": float(np.mean(recs)) if recs else 0.0,
        "macro_f1": float(np.mean(f1s)) if f1s else 0.0,
        "per_class": per,
        "confusion_matrix": cm.tolist(),
        "support_total": int(support.sum()),
        "n_samples": int(len(y_true)),
    }
    if n == 2:
        names = list(class_names)
        pos = names.index(positive) if positive in names else (names.index("yes") if "yes" in names else None)
        if pos is not None:
            sc = None if probs is None else np.asarray(probs, dtype=float)[:, pos]
            out.update(binary_metrics(cm, pos, y_true if sc is not None else None, sc))
    return out


def save_confusion_matrix_png(cm: np.ndarray, class_names: Sequence[str], path: str) -> None:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as exc:
        raise RuntimeError("matplotlib is required to save a confusion-matrix plot") from exc
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(class_names)))
    ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=45, ha="right")
    ax.set_yticklabels(class_names)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center")
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
