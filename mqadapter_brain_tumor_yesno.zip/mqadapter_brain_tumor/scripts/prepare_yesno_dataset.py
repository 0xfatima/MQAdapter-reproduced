#!/usr/bin/env python
"""Turn the raw Kaggle "Brain MRI Images for Brain Tumor Detection" download (Navoneel Chakrabarty,
https://www.kaggle.com/datasets/navoneel/brain-mri-images-for-brain-tumor-detection) into the
Training/Testing image-folder layout the engine reads:

    data/brain_mri_yesno/Training/{no,yes}/*.jpg
    data/brain_mri_yesno/Testing/{no,yes}/*.jpg

Why a preparation step is needed
  * The Kaggle archive has no train/test split: just folders `no/` and `yes/` (mixed .jpg/.JPG/.jpeg/.png,
    grey and colour, many sizes). Most copies of the archive also contain the same images a second time
    under `brain_tumor_dataset/{no,yes}/`.
  * Byte-identical files are removed (the duplicate folder disappears this way). A file that occurs in both
    `no` and `yes` is a label conflict and is dropped.
  * Near-duplicates (16x16 difference hashes within --max-hamming bits, e.g. the same slice re-saved in
    another format or size) are kept but always put into the same split, so they cannot leak from Training into Testing.
  * The split is stratified by class with a fixed seed. No patient IDs are published, so the split is NOT
    patient-independent; report results accordingly.

Usage
    python scripts/prepare_yesno_dataset.py --raw ~/Downloads/archive            # unzipped Kaggle folder
    python scripts/prepare_yesno_dataset.py --zip ~/Downloads/archive.zip        # the zip itself
    python scripts/prepare_yesno_dataset.py --raw RAW --test-ratio 0.2 --seed 0  # defaults shown
    python scripts/prepare_yesno_dataset.py --raw RAW --folds 5                  # + data/brain_mri_yesno_fold{0..4}

Outputs (inside --dest): Training/, Testing/, manifest.csv (every kept file, its source and split) and
prepare_report.json (counts, removed duplicates, conflicts, unreadable files).
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
import sys
import tempfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp", ".gif"}
CLASS_DIRS = {"no": "no", "n": "no", "yes": "yes", "y": "yes"}
CLASSES = ["no", "yes"]


# ----------------------------------------------------------------------------- discovery
def find_class_dirs(raw: Path) -> dict[str, list[Path]]:
    """Every directory called no/yes (case-insensitive) anywhere below `raw`."""
    found: dict[str, list[Path]] = defaultdict(list)
    for p in [raw, *sorted(raw.rglob("*"))]:
        if p.is_dir() and p.name.lower() in CLASS_DIRS and not p.name.startswith("."):
            found[CLASS_DIRS[p.name.lower()]].append(p)
    return found


def list_images(d: Path) -> list[Path]:
    return [p for p in sorted(d.iterdir()) if p.is_file() and p.suffix.lower() in IMAGE_EXTS and not p.name.startswith(".")]


def md5(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()


def dhash(img: Image.Image, size: int = 16) -> str:
    g = np.asarray(img.convert("L").resize((size + 1, size), Image.BILINEAR), dtype=np.int16)
    bits = (g[:, 1:] > g[:, :-1]).flatten()
    return f"{int(''.join('1' if b else '0' for b in bits), 2):0{size * size // 4}x}"


def slug(s: str, n: int = 40) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")
    return (s or "img")[:n]


# ----------------------------------------------------------------------------- collection
def collect(raw: Path) -> tuple[list[dict], dict]:
    dirs = find_class_dirs(raw)
    if not dirs.get("no") or not dirs.get("yes"):
        sys.exit(f"could not find both a 'no' and a 'yes' folder under {raw} (found: { {k: [str(x) for x in v] for k, v in dirs.items()} })")
    by_md5: dict[str, dict] = {}
    labels_of_md5: dict[str, set] = defaultdict(set)
    sources_of_md5: dict[str, list] = defaultdict(list)
    unreadable, n_files, dup_removed = [], 0, []
    for cls in CLASSES:
        for d in dirs[cls]:
            for p in list_images(d):
                n_files += 1
                try:
                    with Image.open(p) as im:
                        im.load()
                        h = dhash(im)
                        size, mode = im.size, im.mode
                except Exception as exc:  # noqa: BLE001
                    unreadable.append({"path": str(p), "error": repr(exc)})
                    continue
                m = md5(p)
                labels_of_md5[m].add(cls)
                sources_of_md5[m].append(str(p))
                if m in by_md5:
                    dup_removed.append({"kept": by_md5[m]["source"], "removed": str(p)})
                    continue
                by_md5[m] = {"source": str(p), "class": cls, "md5": m, "dhash": h, "size": f"{size[0]}x{size[1]}", "mode": mode}
    conflicts = [m for m, ls in labels_of_md5.items() if len(ls) > 1]
    recs = [r for m, r in by_md5.items() if m not in conflicts]
    info = {
        "class_dirs_found": {k: [str(x) for x in v] for k, v in dirs.items()},
        "files_seen": n_files,
        "unreadable": unreadable,
        "exact_duplicates_removed": len(dup_removed),
        "exact_duplicates_sample": dup_removed[:20],
        "label_conflicts_dropped": [{"md5": m, "files": sources_of_md5[m]} for m in conflicts],
    }
    return recs, info


def group_near_duplicates(recs: list[dict], max_hamming: int = 6, max_group: int = 8) -> list[list[int]]:
    """Union-find over records whose 256-bit difference hashes differ in <= max_hamming bits. A merge that would
    create a group larger than max_group is refused, so similar-looking but distinct scans cannot snowball into one
    huge group that breaks the stratified split (prepare_report.json lists the largest group)."""
    n = len(recs)
    parent = list(range(n))
    size = [1] * n

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    if n:
        bits = np.array([[c == "1" for c in f"{int(r['dhash'], 16):0256b}"] for r in recs], dtype=bool)
        for i in range(n):
            d = (bits[i + 1 :] != bits[i]).sum(1)
            for j in np.nonzero(d <= max_hamming)[0]:
                a, b = find(i), find(i + 1 + int(j))
                if a != b and size[a] + size[b] <= max_group:
                    parent[b] = a
                    size[a] += size[b]
    g: dict[int, list[int]] = defaultdict(list)
    for i in range(n):
        g[find(i)].append(i)
    return list(g.values())


def group_label(recs, grp) -> str:
    return Counter(recs[i]["class"] for i in grp).most_common(1)[0][0]


# ----------------------------------------------------------------------------- splitting
def split_groups(recs: list[dict], groups: list[list[int]], test_ratio: float, seed: int) -> dict[int, str]:
    """Group-aware stratified hold-out split -> {record index: "Training" | "Testing"}."""
    rng = np.random.default_rng(seed)
    assign: dict[int, str] = {}
    for cls in CLASSES:
        gs = [g for g in groups if group_label(recs, g) == cls]
        order = rng.permutation(len(gs))
        n_cls = sum(len(g) for g in gs)
        target = int(round(n_cls * test_ratio))
        n_test = 0
        for j in order:
            split = "Testing" if n_test < target else "Training"
            if split == "Testing":
                n_test += len(gs[j])
            for i in gs[j]:
                assign[i] = split
    return assign


def kfold_groups(recs: list[dict], groups: list[list[int]], k: int, seed: int) -> dict[int, int]:
    """Group-aware stratified k-fold -> {record index: fold}. Greedy: each group goes to the fold that has the
    fewest images of its class so far (groups visited in a seeded random order, larger groups first)."""
    rng = np.random.default_rng(seed)
    fold_of: dict[int, int] = {}
    for cls in CLASSES:
        gs = [g for g in groups if group_label(recs, g) == cls]
        perm = rng.permutation(len(gs))
        gs = sorted((gs[j] for j in perm), key=len, reverse=True)
        load = [0] * k
        for g in gs:
            f = int(np.argmin(load))
            load[f] += len(g)
            for i in g:
                fold_of[i] = f
    return fold_of


# ----------------------------------------------------------------------------- writing
def write_layout(recs: list[dict], assign: dict[int, str], dest: Path, overwrite: bool) -> list[dict]:
    if dest.exists():
        if not overwrite:
            sys.exit(f"{dest} already exists; pass --overwrite to rebuild it")
        shutil.rmtree(dest)
    rows = []
    for i, r in enumerate(recs):
        split = assign[i]
        src = Path(r["source"])
        out = dest / split / r["class"] / f"{r['class']}_{i:04d}_{slug(src.stem)}{src.suffix.lower()}"
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, out)
        rows.append({"split": split, "class": r["class"], "path": str(out.relative_to(dest)), "source": r["source"],
                     "md5": r["md5"], "dhash": r["dhash"], "size": r["size"], "mode": r["mode"]})
    with open(dest / "manifest.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return rows


def counts(rows: list[dict]) -> dict:
    c = {s: {k: 0 for k in CLASSES} for s in ("Training", "Testing")}
    for r in rows:
        c[r["split"]][r["class"]] += 1
    return c


def prepare(raw: Path, dest: Path, test_ratio: float = 0.2, seed: int = 0, folds: int = 0, overwrite: bool = False,
            max_hamming: int = 6) -> dict:
    recs, info = collect(raw)
    groups = group_near_duplicates(recs, max_hamming)
    multi = [g for g in groups if len(g) > 1]
    cross_label = [[recs[i]["source"] for i in g] for g in multi if len({recs[i]["class"] for i in g}) > 1]
    report = {
        "dataset": "navoneel/brain-mri-images-for-brain-tumor-detection",
        "raw": str(raw), "dest": str(dest), "seed": seed, "test_ratio": test_ratio, "max_hamming": max_hamming,
        **info,
        "unique_images": {c: sum(1 for r in recs if r["class"] == c) for c in CLASSES},
        "near_duplicate_groups": len(multi),
        "largest_near_duplicate_group": max((len(g) for g in groups), default=0),
        "near_duplicate_groups_sample": [[recs[i]["source"] for i in g] for g in multi[:20]],
        "near_duplicate_groups_with_both_labels": cross_label[:20],
        "image_modes": dict(Counter(r["mode"] for r in recs)),
        "n_unique_sizes": len({r["size"] for r in recs}),
        "patient_split": "No patient IDs exist in this dataset; the split is not patient-independent.",
    }
    rows = write_layout(recs, split_groups(recs, groups, test_ratio, seed), dest, overwrite)
    report["split_counts"] = counts(rows)
    if folds and folds > 1:
        fold_of = kfold_groups(recs, groups, folds, seed)
        report["folds"] = {}
        for f in range(folds):
            fdest = dest.parent / f"{dest.name}_fold{f}"
            frows = write_layout(recs, {i: ("Testing" if fold_of[i] == f else "Training") for i in range(len(recs))}, fdest, overwrite)
            report["folds"][str(fdest)] = counts(frows)
    (dest / "prepare_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--raw", help="folder that contains the Kaggle no/ and yes/ folders (anywhere below it)")
    src.add_argument("--zip", help="the Kaggle archive.zip")
    ap.add_argument("--dest", default=str(ROOT / "data" / "brain_mri_yesno"))
    ap.add_argument("--test-ratio", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=0, help="split seed (independent of the training seeds)")
    ap.add_argument("--folds", type=int, default=0, help="also write K group-stratified folds next to --dest")
    ap.add_argument("--max-hamming", type=int, default=6, help="near-duplicate threshold (bits of 256); 0 = identical hash only")
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()
    if not 0 < args.test_ratio < 1:
        sys.exit("--test-ratio must be in (0, 1)")
    with tempfile.TemporaryDirectory() as tmp:
        if args.zip:
            with zipfile.ZipFile(args.zip) as z:
                z.extractall(tmp)
            raw = Path(tmp)
        else:
            raw = Path(args.raw).expanduser()
        rep = prepare(raw, Path(args.dest), args.test_ratio, args.seed, args.folds, args.overwrite, args.max_hamming)
    print(f"files seen {rep['files_seen']}, exact duplicates removed {rep['exact_duplicates_removed']}, "
          f"label conflicts dropped {len(rep['label_conflicts_dropped'])}, unreadable {len(rep['unreadable'])}")
    print(f"unique images: {rep['unique_images']}; near-duplicate groups kept together: {rep['near_duplicate_groups']} "
          f"(largest {rep['largest_near_duplicate_group']}; inspect near_duplicate_groups_sample in the report)")
    for split, c in rep["split_counts"].items():
        print(f"  {split:8s} {c}")
    for d, c in (rep.get("folds") or {}).items():
        print(f"  {d}: {c}")
    ok = all(rep["split_counts"][s][c] > 0 for s in ("Training", "Testing") for c in CLASSES)
    print(f"report -> {Path(args.dest) / 'prepare_report.json'}")
    print("layout OK" if ok else "layout INCOMPLETE (a split has an empty class)")
    if not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
