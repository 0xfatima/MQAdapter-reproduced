#!/usr/bin/env python
"""Download the Kaggle "Brain MRI Images for Brain Tumor Detection" dataset (Navoneel Chakrabarty) and build
data/brain_mri_yesno/{Training,Testing}/{no,yes} with scripts/prepare_yesno_dataset.py.

    https://www.kaggle.com/datasets/navoneel/brain-mri-images-for-brain-tumor-detection

    python scripts/download_dataset.py                         # kagglehub (needs a Kaggle API token), falls back to the CLI
    python scripts/download_dataset.py --method cli            # Kaggle CLI only (pip install kaggle)
    python scripts/download_dataset.py --zip ~/Downloads/archive.zip   # no token: click "Download" on the Kaggle page
    python scripts/download_dataset.py --raw ~/Downloads/archive       # already unzipped
    python scripts/download_dataset.py --folds 5               # + data/brain_mri_yesno_fold{0..4} for cross-validation

Optional cross-dataset targets (Table III), each needs its own Kaggle download:
    python scripts/download_dataset.py --dataset nickparvar    # 4-class set -> data/brain_tumor_mri (also read as yes/no)

Kaggle token: kaggle.com -> Settings -> API -> Create New Token -> ~/.kaggle/kaggle.json
(or the environment variables KAGGLE_USERNAME / KAGGLE_KEY).
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

SLUGS = {
    "yesno": "navoneel/brain-mri-images-for-brain-tumor-detection",
    "nickparvar": "masoudnickparvar/brain-tumor-mri-dataset",
}


def fetch(slug: str, method: str, tmp: Path) -> Path:
    if method in ("auto", "kagglehub"):
        try:
            import kagglehub

            return Path(kagglehub.dataset_download(slug))
        except Exception as exc:  # noqa: BLE001
            if method == "kagglehub":
                sys.exit(f"kagglehub download failed: {exc!r}")
            print(f"kagglehub failed ({exc!r}); trying the Kaggle CLI", flush=True)
    cmd = ["kaggle", "datasets", "download", "-d", slug, "-p", str(tmp), "--unzip"]
    try:
        subprocess.run(cmd, check=True)
    except (OSError, subprocess.CalledProcessError) as exc:
        sys.exit(f"Kaggle CLI failed ({exc!r}). Download the zip from the Kaggle page and pass --zip PATH.")
    return tmp


def find_train_test(base: Path) -> Path | None:
    for p in [base, *base.rglob("*")]:
        if p.is_dir() and (p / "Training").is_dir() and (p / "Testing").is_dir():
            return p
    return None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dataset", default="yesno", choices=list(SLUGS))
    ap.add_argument("--method", default="auto", choices=["auto", "kagglehub", "cli"])
    ap.add_argument("--zip", default=None)
    ap.add_argument("--raw", default=None)
    ap.add_argument("--dest", default=None)
    ap.add_argument("--test-ratio", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--folds", type=int, default=0)
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()

    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        if args.zip:
            import zipfile

            with zipfile.ZipFile(Path(args.zip).expanduser()) as z:
                z.extractall(tmp)
            src = tmp
        elif args.raw:
            src = Path(args.raw).expanduser()
        else:
            src = fetch(SLUGS[args.dataset], args.method, tmp)

        if args.dataset == "yesno":
            from scripts.prepare_yesno_dataset import CLASSES, prepare

            dest = Path(args.dest or ROOT / "data" / "brain_mri_yesno")
            if dest.exists() and not args.overwrite and (dest / "Training").is_dir():
                print(f"already present: {dest} (pass --overwrite to rebuild)")
                return
            rep = prepare(src, dest, args.test_ratio, args.seed, args.folds, overwrite=True)
            print(f"unique images {rep['unique_images']} (exact duplicates removed: {rep['exact_duplicates_removed']})")
            for split, c in rep["split_counts"].items():
                print(f"  {split:8s} {c}")
            ok = all(rep["split_counts"][s][c] > 0 for s in ("Training", "Testing") for c in CLASSES)
            print("layout OK" if ok else "layout INCOMPLETE")
        else:
            dest = Path(args.dest or ROOT / "data" / "brain_tumor_mri")
            root = find_train_test(src)
            if root is None:
                sys.exit(f"Training/ and Testing/ not found under {src}")
            if dest.exists() or dest.is_symlink():
                if not args.overwrite:
                    print(f"already present: {dest}")
                    return
                dest.unlink() if dest.is_symlink() else shutil.rmtree(dest)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(root, dest)
            print(f"dataset at {dest}\nlayout OK")


if __name__ == "__main__":
    main()
